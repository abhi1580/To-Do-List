let mongoose = require("mongoose");
require("dotenv").config();
let DBURL = process.env.DBURL;
let mongoURL = DBURL;

mongoose.connect(mongoURL, {
  //useNewUrlParser: true,
  //useUnifiedTopology: true,
});
let database = mongoose.connection;

database.on("connected", () => {
  console.log("Connected with database");
});

database.on("error", (error) => {
  console.log("Error connecting database");
});

database.on("disconnected", () => {
  console.log("Disconnecting database");
});
// database.close();
module.exports = database;
