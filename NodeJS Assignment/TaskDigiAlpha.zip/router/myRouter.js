const express = require("express");
const User = require("../model/user");
const myRouter = express.Router();

//GET request to get all users

myRouter.get("/users", async (req, res) => {
  const users = await User.find();
  res.json(users);
});

//GET request to get a single user by name

myRouter.get("/users/:name", async (req, res) => {
  const user = await User.findOne({ firstName: req.params.name });
  if (!user) return res.status(404).json({ message: "User not found" });
  res.json(user);
});

//POST request to create a new user

myRouter.post("/users", async (req, res) => {
  let data = req.body;
  let newUser = new User(data);
  console.log(data);
  try {
    

    const savedUser = await newUser.save();
    res.status(201).json(savedUser);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

//PUT request to update a user except email

myRouter.put("/users/:id", async (req, res) => {
  const user = await User.findByIdAndUpdate(
    req.params.id,
    {
      firstName: req.body.firstName,
      phone: req.body.phone,
      role: req.body.role,
    },
    { new: true }
  );

  if (!user) return res.status(404).json({ message: "User not found" });

  res.json(user);
});
//delete user

myRouter.delete("/users/:id", async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);

  if (!user) return res.status(404).json({ message: "User not found" });

  res.json(user);
});
module.exports = myRouter;
