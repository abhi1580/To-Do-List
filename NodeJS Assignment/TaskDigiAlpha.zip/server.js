const express = require("express");
const app = express();
const database = require("./database/dbConnection");
const router = require("./router/myRouter");
require("dotenv").config();
app.use(express.json());
app.use("/api", router);
let port = process.env.PORT || 4000;

app.listen(port, () => {
  console.log("Express app started on port no 4000");
});
